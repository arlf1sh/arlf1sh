Copyright 2012 by arlf1sh, arlnet
klaytonb@gmail.com

Included are several files that have my whole Befunge standalone
interpreter.  While this strays from BF'98 in that it only supports
unefunge and befunge (1- and 2-dimensional scripts only, no 3+d
support) as well as only what I deemed are the 'most important'
aspects of the language, it is functionally different from BF'93
in that the size is larger and a few more commands are available.

See the included 'dice.bf' file for example.

  "Befunge/" folder holds the entire Eclipse project, which can be
imported just like any other project.  It holds the three Java
classes in source and binary.
  "befunjava.jar" is the compiled/"executable" form of the project.
I wrote a bash shortcut script (not included) that runs it with the
following command in a Linux terminal:
java -jar befunjava.jar $1
Under Windows, you might can run a similar program from the command
prompt, but you may need to ask Google for help on that one.
  "dice.bf" is the included befunge script that I wrote months ago.
It rolls n number of 2/3/4/6/8/10/12/20-sided dice.
