//(c)2012 arlf1sh, arlnet

import java.util.Stack;
import java.io.File;

public class Run {
	
	public static void main(String[] args) {
		try {
			if (args.length==0) throw new Exception("Filename needed!");
			if (args.length>7) throw new Exception("Too many arguments!");
			
			String fi = args[0].toString();
			File f = new File(fi);
			if (!f.exists()) throw new Exception("File doesn't exist!");
			
			Stack<Integer> st = new Stack<Integer>();
			for (int i=1;i<args.length && i<7;i++) st.push( getIntValue(args[i].charAt(0)));
			
			switch (args.length-1) {
			case 6 : Interpret.F = st.pop();
			case 5 : Interpret.E = st.pop();
			case 4 : Interpret.D = st.pop();
			case 3 : Interpret.C = st.pop();
			case 2 : Interpret.B = st.pop();
			case 1 : Interpret.A = st.pop();
			}
			
			Interpret.file(fi, st);
			System.out.println();
		} catch (Exception e) {
			System.out.println("[!] "+e);
		}
	}
	
	private static int getIntValue(char c) {
		int i= (int) c;
		if (i>=48 && i<59) i-=48;
		
		return i;
	}
}
