//(c)2012 arlf1sh, arlnet

import java.io.File;
import java.util.Scanner;
import java.util.Stack;

public class BF {
	public int Lx=0;
	public int Ly=0;
	public char[][] fs;
	
	public BF(String fn) {
		try {
			File bf = new File(fn);
			Scanner sc = new Scanner(bf);
			String sr="";
			Stack<String> st = new Stack<String>();
			
			for (Ly=0;sc.hasNext();Ly++) {
				sr = sc.nextLine();
				if (Lx<sr.length())
					Lx = sr.length();
				st.push(sr);
			}
			
			fs = new char[Lx][Ly];
			
			for (int y=Ly-1;y>=0;y--) {
				sr = (String) st.pop();
				for (int x=0;x<Lx;x++) {
					try {
						fs[x][y] = sr.charAt(x);
					} catch (Exception f) {
						fs[x][y] = ' ';
					}
				}
			}
			sc.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
}
