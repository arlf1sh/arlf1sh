//(c)2012 arlf1sh, arlnet

import java.util.Stack;
import java.util.Scanner;
import java.util.Random;

public class Interpret {
	static Boolean end;
	static BF bf;
	static char[][] fs;
	static int Lx;	//limit xY
	static int Ly;
	static byte d;	//"delta", direction of pointer
	static int ipX;	//current x/y location
	static int ipY;
	static Stack<Integer> st;
	static int a;	//temp holding cells for number operations
	static int b;	//probably "cheating", so i might edit it functionality-wise
	static boolean stringmode=false;
	static boolean skipmode=false;
	static Scanner in;
	static Object ob;

	static Random r = new Random();
	
	static int A;
	static int B;
	static int C;	//Custom, blank variables that might be used
	static int D;	//by the Befunge program.
	static int E;
	static int F;
	
	public static void file(String fi, Stack<Integer> stack) {
		st = stack;
		
		end = false;
		bf = new BF(fi); // "BF" holds the 'map' file / "fungespace"
		fs = bf.fs;	//fungespace				   0
		Lx=bf.Lx;	//x limit					   |
		Ly=bf.Ly;	//y limit				    3--+--1  delta compass
		d = 1;	//the 'delta', or direction		   |
		ipX=0;	//the x of the ip				   2
		ipY=0;	//the y of the ip
		in = new Scanner(System.in);
		r = new Random();
		
		try {
			while (!end) {
				if (stringmode) {
					if (fs[ipX][ipY]=='"') stringmode=false;
					else push((int) (char) fs[ipX][ipY]);
				} else if (skipmode) {
					if (fs[ipX][ipY]==';') skipmode=false;
				} else {
					switch (fs[ipX][ipY]) {
					case ' ' : break;
					case '@' : end=true; break;
					case '>' : d=1; break;
					case 'v' : d=2; break;
					case '<' : d=3; break;
					case '^' : d=0; break;
					case ':' : a(); push(a); push(a); break;
					case '0' : push(0); break;
					case '1' : push(1); break;
					case '2' : push(2); break;
					case '3' : push(3); break;
					case '4' : push(4); break;
					case '5' : push(5); break;
					case '6' : push(6); break;
					case '7' : push(7); break;
					case '8' : push(8); break;
					case '9' : push(9); break;
					case 'a' : push(10); break;
					case 'b' : push(11); break;
					case 'c' : push(12); break;
					case 'd' : push(13); break;
					case 'e' : push(14); break;
					case 'f' : push(15); break;
					case 'r' : reflect(); break;
					case 'w' : w(); break;
					case '[' : turnLeft(); break;
					case ']' : turnRight(); break;
					case '_' : ifH(); break;
					case '|' : ifV(); break;
					case '+' : b(); a(); push(a+b); break;
					case '-' : b(); a(); push(a-b); break;
					case '*' : b(); a(); push(a*b); break;
					case '/' : b(); a(); push((int) Math.floor(a/b)); break;
					case '\\': b(); a(); push(b); push(a); break;
					case '%' : b(); a(); push(a%b); break;
					case '"' : stringmode=true; break;
					case '#' : trampoline(); break;
					case '$' : a(); break;
					case '&' : push(in.nextInt()); break;
					case '~' : push((int) in.nextLine().charAt(0)); break;
					case ',' : System.out.print(Character.toChars((int) pop())); break;
					case '.' : System.out.print(pop()+" "); break;
					case ';' : skipmode=true; break;
					case '?' : random(); break;
					case 'A' : push(A); break;
					case 'B' : push(B); break;
					case 'C' : push(C); break;
					case 'D' : push(D); break;
					case 'E' : push(E); break;
					case 'F' : push(F); break;
					
					default : System.out.println("[?] Input char ["+((char) fs[ipX][ipY])+"] not recognized, skipping...");
					}
				}
				
				deltaNext();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private static void deltaNext() {
		if (d==0) {
			ipY--; if (ipY==-1) ipY=Ly-1;
		} else if (d==1) {
			ipX++; if (ipX==Lx) ipX=0;
		} else if (d==2) {
			ipY++; if (ipY==Ly) ipY=0;
		} else if (d==3) {
			ipX--; if (ipX==-1) ipX=Lx-1;
		} else d=1;
	}
	
	private static Object pop() {
		try {
			ob = st.pop();
		} catch (Exception e) {
			ob = (int) 0;
		}
		
		return ob;
	}
	private static void push(int o) {
		st.push((Integer) o);
	}
	
	private static void a() {
		a=(Integer) pop();
	}
	private static void b() {
		b=(Integer) pop();
	}
	
	private static void turnLeft() {	//	'['
		if (d==0) d=3; else d-=1;
	}
	private static void turnRight() {	//	']'
		if (d==3) d=0; else d+=1;
	}
	private static void w() {			//	'w'
		b();
		a();						//  <--- a<b
		if (a<b) turnLeft();		//           when ^
		else if (a>b) turnRight();	//  ---> a>b
	}
	private static void reflect() {	//		'r'
		d+=2;
		if (d>3) d-=4;
	}
	private static void random() {	//		'?'
		int temp = r.nextInt(4);
		switch (temp) {
			case 0: d=0; break;
			case 1: d=1; break;
			case 2: d=2; break;
			case 3: d=3; break;
		}
	}
	
	private static void ifH() {		//		'_'
		a();
		if (a==0) d=1; else d=3;
	}
	private static void ifV() {		//		'|'
		a();
		if (a==0) d=2; else d=0;
	}
	
	private static void trampoline() {	//	'#'
		deltaNext();
	}
}
