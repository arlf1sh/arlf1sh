import java.util.Scanner;
import charinfo.Player;
import Races.*;

public class CharacterCreator 
{	
	public static void raceSelect(Player p)
	{
		Scanner scan = new Scanner(System.in);
		System.out.println("Choose a race from the following list: \n" +
				"Dwarf, Elf, Gnome, Half-Elf, Halfling, Half-Orc, Human");
		boolean k;
		do {
			String race = scan.nextLine();
			race.toLowerCase();
			k=false;
			switch (race)
			{
			case "dwarf" : p.RACE = new Races.dwarf(); break;
			case "elf" : p.RACE = new Races.elf(); break;
			case "gnome" : p.RACE = new Races.gnome(); break;
			case "half-elf" : p.RACE = new Races.halfElf(); break;
			case "halfling" : p.RACE = new Races.halfling(); break;
			case "half-orc" : p.RACE = new Races.halfOrc(); break;
			case "human" : p.RACE = new Races.human(); break;
			default : System.out.println("you suck"); k=true;
			}
		} while (k);
		
		p.size=p.RACE.size;
	}
	
	public static void classSelect(Player p)
	{
		Scanner scann = new Scanner(System.in);
		System.out.println("Choose a class from the following list:\n" +
				"Barbarian, Bard, Cleric, Druid, Fighter, Monk, Paladin, Ranger, Rogue, Sorcerer, Wizard");
		boolean k;
		do { 
			k=false;
			String c = scann.nextLine();
			c.toLowerCase();
			switch (c)
			{
			case "barbarian" : p.CLASS = new Classes.Barbarian(); break;
			case "bard" : p.CLASS = new Classes.Bard(); break;
			case "cleric" : p.CLASS = new Classes.Cleric(); break;
			case "druid" : p.CLASS = new Classes.Druid(); break;
			case "fighter" : p.CLASS = new Classes.Fighter(); break;
			case "monk" : p.CLASS = new Classes.Monk(); break;
			case "paladin" : p.CLASS = new Classes.Paladin(); break;
			case "ranger" : p.CLASS = new Classes.Ranger(); break;
			case "rogue" : p.CLASS = new Classes.Rogue(); break;
			case "sorcerer" : p.CLASS = new Classes.Sorcerer(); break;
			case "wizard" : p.CLASS = new Classes.Wizard(); break;
			default : System.out.println("you suck"); k=true;
			//case "example" : Player.CLASS="barbarian"; break;
			}
		} while (k);
		
		p.gold=p.CLASS.money;
	}
}

