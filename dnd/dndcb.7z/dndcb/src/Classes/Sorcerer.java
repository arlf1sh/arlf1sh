package Classes;

public class Sorcerer extends Classes
{
	public static void Sorcerer()
	{
		name="Sorcerer";
		hitDie=4;
		skillPoints=2;
		BAB=0;
		fortSave=0;
		refSave=0;
		willSave=2;
		simpleProf=true;
		spells[0]=5;
		spells[1]=3;
		int[] spellsKnown = new int[9];
		spellsKnown[0]=4;
		spellsKnown[1]=2;
		special = "summon familiar";
		money = 75;
		
	}
}
