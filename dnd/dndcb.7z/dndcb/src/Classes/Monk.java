package Classes;

public class Monk extends Classes
{
	public static void Monk()
	{
		name="Monk";
		hitDie=8;
		skillPoints=4;
		BAB=0;
		fortSave=2;
		refSave=2;
		willSave=2;
		special = "bonus feat at level 1 and at every even numbred level thereafter.\n" +
				"proficient with club, crossbow(light or heavy), dagger, handaxe, javelin, kama, nunchaku, quarterstaff, sai, shuriken, siangham, sling\n" +
				"flurry of blows, unarmed strike.";
		money = 12.5;
	}
}
