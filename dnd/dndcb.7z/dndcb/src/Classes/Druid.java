package Classes;

public class Druid extends Classes
{
	public static void Druid()
	{
		name="Druid";
		hitDie=8;
		skillPoints=4;
		BAB=0;
		fortSave=2;
		refSave=0;
		willSave=2;
		lightProf=true;
		medProf=true;
		shieldProf=true;
		spells[0]=3;
		spells[1]=1;
		special = "animal companion, nature sense, wild empathy\n" +
				"proficient with club, dagger, scimitar, sickle, shortsword, sping, spear\n" +
				"cannot wear metal armor";
		money = 50;
	}
}
