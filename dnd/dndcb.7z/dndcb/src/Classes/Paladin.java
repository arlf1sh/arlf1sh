package Classes;

public class Paladin extends Classes
{
	public static void Paladin()
	{
		name = "Paladin";
		hitDie=10;
		skillPoints=2;
		BAB=1;
		fortSave=2;
		refSave=0;
		willSave=0;
		lightProf=true;
		medProf=true;
		heavyProf=true;
		shieldProf=true;
		simpleProf=true;
		marshalProf=true;
		special = "aura of good, detect evil, smite evil 1/day";
		money = 150;
	}
}
