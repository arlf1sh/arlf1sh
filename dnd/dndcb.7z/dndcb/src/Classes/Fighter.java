package Classes;

public class Fighter extends Classes
{
	public static void Fighter()
	{
		name="Fighter";
		hitDie=10;
		skillPoints=2;
		BAB=1;
		fortSave=2;
		refSave=0;
		willSave=0;
		lightProf=true;
		medProf=true;
		heavyProf=true;
		simpleProf=true;
		marshalProf=true;
		shieldProf=true;
		twrShieldProf=true;
		special = "1 bonus feat at level 1 and at every even numbered level thereafter.";
		money = 150;
	}
}
