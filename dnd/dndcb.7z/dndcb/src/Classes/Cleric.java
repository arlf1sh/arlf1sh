package Classes;

public class Cleric extends Classes
{	
	public static void Cleric()
	{
		name="Cleric";
		hitDie=8;
		skillPoints=2;
		BAB=0;
		fortSave=2;
		refSave=0;
		willSave=2;
		lightProf=true;
		medProf=true;
		heavyProf=true;
		simpleProf=true;
		spells[0]=3;
		spells[1]=2;
		special = "turn/rebuke undead";
		money = 125;
	}
}
