package Classes;

public class Rogue extends Classes
{
	public static void Rogue()
	{
		name="Rogue";
		hitDie=6;
		skillPoints=8;
		BAB=0;
		fortSave=0;
		refSave=2;
		willSave=0;
		lightProf=true;
		simpleProf=true;
		special = "sneak attack +1d6, trapfinding\n" +
				"proficient with hand crossbow, rapier, shortbow, shortsword";
		money = 125;
	}
}
