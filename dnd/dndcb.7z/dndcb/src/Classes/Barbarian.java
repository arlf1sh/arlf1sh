package Classes;

public class Barbarian extends Classes
{
	public static void Barbarian()
	{
		name="Barbarian";
		hitDie=12;
		skillPoints=4;
		BAB=1;
		fortSave=2;
		refSave=0;
		willSave=0;
		lightProf=true;
		medProf=true;
		shieldProf=true;
		simpleProf=true;
		marshalProf=true;
		special = "fast movement, illiteracy, rage 1/day";
		money = 100;
	}
}
