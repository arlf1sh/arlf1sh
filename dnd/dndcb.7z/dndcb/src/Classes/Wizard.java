package Classes;

public class Wizard extends Classes
{
	public static void Wizard()
	{
		name="Wizard";
		hitDie=4;
		skillPoints=2;
		BAB=0;
		fortSave=0;
		refSave=0;
		willSave=2;
		spells[0]=3;
		spells[1]=1;
		special = "summon familiar, scribe scroll";
		money = 75;
	}
}
