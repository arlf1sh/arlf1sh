package Classes;

public class Classes 
{
	public static String name="Monk";
	public static int hitDie;
	public static int skillPoints;
	public static int BAB;
	public static int fortSave;
	public static int refSave;
	public static int willSave;
	public static int[] spells = new int[9];
	public static boolean lightProf=false;
	public static boolean medProf=false;
	public static boolean heavyProf=false;
	public static boolean shieldProf=false;
	public static boolean twrShieldProf=false;
	public static boolean simpleProf=false;
	public static boolean marshalProf=false;
	public static String special;
	public static double money;
}
