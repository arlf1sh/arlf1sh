package Classes;

public class Ranger extends Classes
{
	public static void Ranger()
	{
		name="Ranger";
		hitDie=8;
		skillPoints=6;
		BAB=1;
		fortSave=2;
		refSave=2;
		willSave=0;
		lightProf=true;
		shieldProf=true;
		simpleProf=true;
		marshalProf=true;
		special = "1st favored enemy, Track, wild empathy";
		money = 150;
	}
}
