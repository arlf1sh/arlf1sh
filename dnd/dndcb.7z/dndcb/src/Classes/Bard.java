package Classes;

public class Bard extends Classes
{
	public static void Bard()
	{
		name="Bard";
		hitDie=6;
		skillPoints=6;
		BAB=0;
		fortSave=0;
		refSave=2;
		willSave=2;
		lightProf=true;
		shieldProf=true;
		simpleProf=true;
		spells[0]=4;
		special = "bardic music, bardic knowledge, countersong, fascinate, inspire courage +1\n" +
				"proficient with longsword, rapier, sap, shortsword, shortbow, whip.";
		money = 100;
		
	}
}
