package Races;

public class Skill 
{
	 public String name;
	 public int ability;
	 public int ranks;
	 public int modRacial;
	 public int modSynergy;
	
	public Skill(String n, int i, int r, int mR, int mS) 
	{
		name=n;
		ability=i;
		ranks=r;
		modRacial=mR;
		modSynergy=mS;
	}
	
}
