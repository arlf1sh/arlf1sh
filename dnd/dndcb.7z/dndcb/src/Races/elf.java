package Races;


public class elf extends Race{
	public static void elf()
	{
		name="Elf";
		DEXadjust+=2;
		CONadjust-=2;
		languages.push("common");
		languages.push("elven");
		speed=30;
		Skill[] skills = Race.InitializeSkills();
		skills[19].modRacial = 2;
		skills[25].modRacial = 2;
		skills[29].modRacial = 2;	
		favoredClass = "wizard";
		size = 'M';
		vision = "low-light";
		String otherTraits = "immunity to sleep, +2 bonus to saves against enchantment spells/effects\n" +
				"weapon proficiency: longsword, rapier, longbow(including composite), shortbow(including composite)\n" +
				"sixth sense about hidden portals";
		
	}
}
