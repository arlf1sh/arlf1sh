package Races;

import java.util.Stack;
public class Race 
{
	public static String name="Dwarf";
	public static int STRadjust;
	public static int DEXadjust;
	public static int CONadjust;
	public static int INTadjust;
	public static int WISadjust;
	public static int CHAadjust;
	public static Stack languages = new Stack();
	public static int speed;
	public static int ACbonus;
	public static int attackBonus;
	public static String favoredClass;
	public static char size;
	public static String vision;
	
	public static Skill[] InitializeSkills()
	{
		Skill[] skills = new Skill[35];
	
		skills[0] = new Skill("Appraise", 3,0,0,0);
		skills[1] = new Skill("Balance",1,0,0,0);
		skills[2] = new Skill("Bluff",5,0,0,0);
		skills[3] = new Skill("Climb",0,0,0,0);
		skills[4] = new Skill("Concentration",2,0,0,0);
		skills[5] = new Skill("Craft",3,0,0,0);
		skills[6] = new Skill("Decipher script",3,0,0,0);
		skills[7] = new Skill("Diplomacy",5,0,0,0);
		skills[8] = new Skill("Disable device",3,0,0,0);
		skills[9] = new Skill("Disguise",5,0,0,0);
		skills[10] = new Skill("Escape artist",1,0,0,0);
		skills[11] = new Skill("Forgery",3,0,0,0);
		skills[12] = new Skill("Gather information",5,0,0,0);
		skills[13] = new Skill("Handle animal",5,0,0,0);
		skills[14] = new Skill("Heal",4,0,0,0);
		skills[15] = new Skill("Hide",1,0,0,0);
		skills[16] = new Skill("Intimidate",5,0,0,0);
		skills[17] = new Skill("Jump",0,0,0,0);
		skills[18] = new Skill("Knowledge",3,0,0,0);
		skills[19] = new Skill("Listen",4,0,0,0);
		skills[20] = new Skill("Move silently",1,0,0,0);
		skills[21] = new Skill("Open lock",1,0,0,0);
		skills[22] = new Skill("Perform",5,0,0,0);
		skills[23] = new Skill("Proffesion",4,0,0,0);
		skills[24] = new Skill("Ride",1,0,0,0);
		skills[25] = new Skill("Search",3,0,0,0);
		skills[26] = new Skill("Sense motive",4,0,0,0);
		skills[27] = new Skill("Sleight of hand",1,0,0,0);
		skills[28] = new Skill("Spellcraft",3,0,0,0);
		skills[29] = new Skill("Spot",4,0,0,0);
		skills[30] = new Skill("Survival",4,0,0,0);
		skills[31] = new Skill("Swim",0,0,0,0);
		skills[32] = new Skill("Tumble",1,0,0,0);
		skills[33] = new Skill("Use magic device",5,0,0,0);
		skills[34] = new Skill("Use rope",1,0,0,0);
		return skills;
	}
	
}
