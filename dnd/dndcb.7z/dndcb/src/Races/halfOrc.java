package Races;


public class halfOrc extends Race{
	public static void halfOrc()
	{
		name="Half-Orc";
		STRadjust+=2;
		INTadjust-=2;
		CHAadjust-=2;
		languages.push("common");
		languages.push("orcish");
		speed=30;
		Skill[] skills = Race.InitializeSkills();
		favoredClass = "barbarian";
		size = 'M';
		vision = "darkvision";
		String otherTraits = "Orc blood: for all effects related to race, half-orcs are considered orcs.";
		
		
		
	}
}
