package Races;


public class gnome extends Race{
	public static void gnome()
	{
		name="Gnome";
		CONadjust+=2;
		STRadjust-=2;
		languages.push("common");
		languages.push("gnomish");
		speed=20;
		Skill[] skills = Race.InitializeSkills();
		skills[15].modRacial = 4;
		skills[19].modRacial = 2;
		ACbonus+=1;
		attackBonus+=1;
		favoredClass = "bard";
		size = 'S';
		vision = "low-light";
		String otherTraits = "weapon familiarity: may treat gnome hooked hammers as martial weapons\n" +
				"+2 on saves against illusions\n" +
				"+1 to DC of illusion spells cast by gnomes\n" +
				"+1 to attack rolls against kobolds and goblinoids\n" +
				"+4 dodge bonus to AC against monsters of the giant type\n" +
				"+2 bonus to craft(alchemy) checks\n" +
				"spell-like abilities: 1/day - speak with animals(burrowing mammals only)\n" +
				"	gnome with charisma score of at least 10 has the following as well:\n" +
				"		1/day - dancing lights, ghost sound, prestidigitation\n" +
				" 	caster level 1st; DC = 10 + Cha mod + spell level";
	}
}
