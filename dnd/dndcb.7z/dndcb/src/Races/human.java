package Races;


public class human extends Race
{
	public static void human()
	{
		name="Human";
		languages.push("common");
		speed=30;
		Skill[] skills = Race.InitializeSkills();
		favoredClass = "any";
		size = 'M';
		vision = "normal";
		String otherTraits = "4 extra skill points at level 1 and 1 additional point per level\n" +
				"1 additional feat at first level.";
	}
}
