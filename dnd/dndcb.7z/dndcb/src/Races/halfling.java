package Races;


public class halfling extends Race{
	public static void halfling()
	{
		name="Halfling";
		DEXadjust+=2;
		STRadjust-=2;
		languages.push("common");
		languages.push("halfling");
		speed=20;
		Skill[] skills = Race.InitializeSkills();
		skills[15].modRacial = 4;
		skills[3].modRacial = 2;
		skills[17].modRacial = 2;
		skills[20].modRacial = 2;
		skills[19].modRacial = 2;
		ACbonus+=1;
		attackBonus+=1;
		favoredClass = "rogue";
		size = 'S';
		vision = "normal";
		String otherTraits = "+1 bonus on all saving throws\n" +
				"+2 moral bonus on saving throws against fear(stacks with +1 on all saves bonus)\n";
		
		
	}
}
