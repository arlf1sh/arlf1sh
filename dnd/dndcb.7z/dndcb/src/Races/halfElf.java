package Races;


public class halfElf extends Race{
	public static void halfElf()
	{
		name="Half-Elf";
		languages.push("common");
		languages.push("elven");
		speed=30;
		Skill[] skills = Race.InitializeSkills();
		skills[19].modRacial = 1;
		skills[25].modRacial = 1;
		skills[29].modRacial = 1;
		skills[7].modRacial = 2;
		skills[12].modRacial = 2;
		favoredClass = "any";
		size = 'M';
		vision = "low-light";
		String otherTraits = "Elven Blood: for all effects related to race, laf elf is considered an elf.";
	}
}
