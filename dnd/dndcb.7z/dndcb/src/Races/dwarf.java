package Races;


public class dwarf extends Race 
{
	public static void dwarf()
	{
		name="Dwarf";
		CONadjust+=2;
		CHAadjust-=2;
		languages.push("common");
		languages.push("dwarven");
		speed=20;
		Skill[] skills = Race.InitializeSkills();
		favoredClass = "fighter";
		size = 'M';
		vision = "darkvision";
		String otherTraits = "Dwarves can move at full speed even with heavy armor and medium/heavy load\n " +
				"Stonecunning: +2 to search for stonework; sixth sense about stonework; can sense depth\n" +
				"Weapon familiarity: can treat dwarven waraxes and dwarven urgoshes as martial weapons\n" +
				"Stability: bonus to being bull rushed/tripped when standing\n" +
				"+2 to saving throws against poison, spells, and spell-like effects\n" +
				"+1 on attack rolls against orcs and goblinoids\n" +
				"+4 dodge bonus to AC against monsters of the giant type\n" +
				"+2 bonus to appraise and craft only if stone/metal";
				
	}
}
