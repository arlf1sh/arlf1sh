package data;

public class Class {
	String name;
	int hitdice;
	
}
