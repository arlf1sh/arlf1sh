package data;

public class Armor extends Item {
	public char type;
	public int ac_bonus;
	public int max_dex;
	public int check_penalty;
	public int spell_failure;
	public boolean speedy;
	
	public Armor(String name, int c, int lbs, char t, int ac, int md, int cp, int sf, boolean sp) {
		super.name = name;
		super.cost = c;
		super.weight = lbs;
		type = t;
		ac_bonus = ac;
		max_dex = md;
		check_penalty = cp;
		spell_failure = sf;
		speedy = sp;
	}
}
