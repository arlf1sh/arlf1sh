package data;

public class ArmorList {
	
	public static Armor none = new Armor("None", 0, 0, 'L', 0, 20, 0, 0, true);
	
	// String name, int c, int lbs, char t, int ac, int md, int cp, int sf, boolean sp
	public static Armor padded = new Armor("Padded Armor", 5, 10, 'L', 1, 8, 0, 5, true);
	public static Armor leather = new Armor("Leather Armor", 10, 15, 'L', 2, 6, 0, 10, true);
	public static Armor leatherStud = new Armor("Studded Leather Armor", 25, 20, 'L', 3, 5, 1, 15, true);
	public static Armor chainShirt = new Armor("Chain Shirt", 100, 25, 'L', 4, 4, 2, 20, true);
	
	public static Armor hide = new Armor("Hide Armor", 15, 25, 'M', 3, 4, 3, 20, false);
	public static Armor scalemail = new Armor("Scale mail", 50, 30, 'M', 4, 3, 4, 25, false);
	public static Armor chainmail = new Armor("Chainmail", 150, 40, 'M', 5, 2, 5, 30, false);
	public static Armor breastplate = new Armor("Breastplate", 200, 30, 'M', 5, 3, 4, 25, false);
	
	public static Armor splintmail = new Armor("Splint mail", 200, 45, 'H', 6, 0, 7, 40, false);
	public static Armor bandedmail = new Armor("Banded mail", 250, 35, 'H', 6, 1, 6, 35, false);
	public static Armor halfplate = new Armor("Half-Plate", 600, 50, 'H', 6, 0, 7, 40, false);
	public static Armor fullplate = new Armor("Full Plate", 1500, 50, 'H', 8, 1, 6, 35, false);
}
