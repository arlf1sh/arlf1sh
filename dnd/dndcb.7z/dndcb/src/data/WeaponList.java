package data;

public class WeaponList {
	// String n, char c1, char c2, int c, int a1, int b2, String crit, int lbs, char dt
	
	public static Weapon none = new Weapon("Unarmed Strike",'S','L',0,1,6,"x2",0,'B');
	//'S'imple weapons
		//'L'ight melee
	public static Weapon dagger = new Weapon("Dagger", 'S', 'L', 2, 1, 4, "19-20/x2", 1, 'P');
	public static Weapon mace_light = new Weapon("Light Mace", 'S', 'L', 5, 1, 6, "x2", 4, 'B');
	public static Weapon sickle = new Weapon("Sickle", 'S', 'L', 5, 1, 6, "x2", 2, 'S');
		//'1'-handed
	public static Weapon club = new Weapon("Club", 'S', '1', 0,1,6,"x2",3,'B');
	public static Weapon mace_heavy = new Weapon("Heavy Mace", 'S', '1', 12, 1, 8, "x2", 6, 'B');
	public static Weapon morningstar = new Weapon("Morningstar", 'S', '1', 8, 1, 8, "x2", 6, 'B');
		//'2'-handed
	public static Weapon spear = new Weapon("Spear", 'S', '2', 5, 1, 8, "x3", 9, 'P');
	public static Weapon quarterstaff = new Weapon("Quarterstaff", 'S', '2', 0, 1,6, "x2", 4, 'B');
		//'R'anged
	public static Weapon crossbow_heavy = new Weapon("Heavy Crossbow", 'S', 'R', 50, 1, 10, "19-20/x2", 8, 'P');
	public static Weapon crossbow_light = new Weapon("Light Crossbow", 'S', 'R', 35, 1, 8, "19-20/x2", 4, 'P');
	public static Weapon javelin = new Weapon("Javelin", 'S', 'R', 1, 1, 6, "x2", 2, 'P');
	public static Weapon sling = new Weapon("Sling", 'S', 'R', 0, 1, 4, "x2", 0, 'B');
	
	//'M'artial weapons
		//'Light' melee
	public static Weapon[] martial = {
	new Weapon("Throwing Axe", 'M', 'L', 8, 1, 6, "x2", 2, 'S'),
	new Weapon("Light Hammer", 'M', 'L', 1, 1, 4, "x2", 2, 'B'),
	new Weapon("Handaxe",'M', 'L', 6, 1, 6, "x3", 2, 'S'),
	new Weapon("Kukri", 'M', 'L', 8, 1,4,"18-20/x2",2,'S'),
	new Weapon("Short sword",'M','L',10,1,6,"19-20/x2",2,'P'),
		//'1'-handed
	new Weapon("Battleaxe", 'M','1',10,1,8,"x3",6,'S'),
	new Weapon("Flail",'M','1',8,1,8,"x2",5,'B'),
	new Weapon("Longsword", 'M','1',15,1,8,"19-20/x2",4,'S'),
	new Weapon("Rapier", 'M', '1', 20,1,6,"18-20/x2",2,'P'),
	new Weapon("Scimitar", 'M', '1', 15, 1, 6, "18-20/x2", 4, 'S'),
	new Weapon("Warhammer", 'M', '1', 12, 1,8,"x3",5,'B'),
		//'2'-handed
	new Weapon("Falchion", 'M', '2', 75, 2,4,"18-20/x2",8,'S'),
	new Weapon("Greataxe", 'M', '2', 20,1,12,"x3",10,'S'),
	new Weapon("Greatclub",'M','2',5,1,10,"x2",8,'B'),
	new Weapon("Heavy Flail", 'M','2',15,1,10,"19-20/x2",10,'B'),
	new Weapon("Greatsword", 'M','2',50,2,6,"19-20/x2",8,'S'),
		//'R'anged
	new Weapon("Longbow",'M','R',75,1,8,"x3",3,'P'),
	new Weapon("Shortbow",'M','R',30,1,6,"x3",2,'P')
	};
	
	public static void showList(Weapon w) {
		System.out.println(w.name+" ("+w.cost+")");
	}
	public static Weapon checkList(String x) {
		for (int i=0;i<martial.length;i++) {
			if (martial[i].name.toUpperCase().equals(x)) return martial[i];
		}
		return none;
	}
}
