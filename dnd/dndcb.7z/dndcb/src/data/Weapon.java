package data;

public class Weapon extends Item {
	public char cat1;
	public char cat2;
	public String critical;
	public char dtype;
	
	int a,b;
	
	public Weapon(String n, char c1, char c2, int c, int a1, int b2, String crit, int lbs, char dt) {
		super.name = n; super.cost = c; super.weight = lbs;
		cat1 = c1; cat2 = c2; critical=crit; dtype=dt;
		a=a1; b=b2;
	}
	
	public String damage() {
		
		return (a+"d"+b);
	}
}
