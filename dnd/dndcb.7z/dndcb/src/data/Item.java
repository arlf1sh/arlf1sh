package data;

public class Item {
	public String name;
	public int cost;
	public int weight;
}
