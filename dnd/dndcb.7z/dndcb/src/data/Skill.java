package data;

public class Skill {
	String name;
	char ability; //0-7 for str-cha
	int ranks;
	int modRacial;
	int modSynergy;
	
	public Skill(String n, char a, int r, int mR, int mS) {
		name = n;
		ability = a;
		ranks = r;
		modRacial = mR;
		modSynergy = mS;
	}
}
