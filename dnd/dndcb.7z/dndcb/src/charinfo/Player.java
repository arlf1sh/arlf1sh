package charinfo;
import java.math.*;
import data.*;
import Races.*;
import Races.Skill;
import Classes.*;

public class Player {
	public Classes CLASS;
	public Race RACE;
	public char size;
	int sizeBonus() {
		if (size == 'S') return 1;
		else return 0;
	}
	
	public double gold;
	
	Skill[] skills = RACE.InitializeSkills();
	Armor armor = ArmorList.none;
	Weapon weapon = WeaponList.none;
	
	public int AC() {
		return 10 + dexBonus() + armor.ac_bonus + sizeBonus();
	}
	public int AC_Touch() {
		return 10+dexBonus() + sizeBonus();
	}
	public int AC_Flat() {
		return 10+armor.ac_bonus + sizeBonus();
	}
	public int HP() {
		return conStat()+CLASS.hitDie;
	}
	public int SPEED() {
		if (size=='M') return 30;
		else return 20;
	}
	public int INITIATIVE() {
		return dexStat();
	}
	
	//strength, dexterity, constitution, intelligence, wisdom, charisma
	public int strBase=0;
	public int strStat() {
		return strBase;
	}
	public int strBonus() {
		return (int) Math.floor((strBase+RACE.STRadjust-10)/2);
	}
	
	public int dexBase=0;
	public int dexStat() {
		return dexBase;
	}
	public int dexBonus() {
		return (int) Math.floor((dexBase+RACE.DEXadjust-10)/2);
	}
	
	public int conBase=0;
	public int conStat() {
		return conBase;
	}
	public int conBonus() {
		return (int) Math.floor((conBase+RACE.CONadjust-10)/2);
	}
	
	public int intBase=0;
	public int intStat() {
		return intBase;
	}
	public int intBonus() {
		return (int) Math.floor((intBase+RACE.INTadjust-10)/2);
	}
	
	public int wisBase=0;
	public int wisStat() {
		return wisBase;
	}
	public int wisBonus() {
		return (int) Math.floor((wisBase+RACE.WISadjust-10)/2);
	}
	
	public int chaBase=0;
	public int chaStat() {
		return chaBase;
	}
	public int chaBonus() {
		return (int) Math.floor((chaBase+RACE.CHAadjust-10)/2);
	}
	
	//saving throws
	public int fortitude() {
		return conStat()+CLASS.fortSave;
	}
	public int reflex() {
		return dexStat()+CLASS.refSave;
	}
	public int will() {
		return wisStat()+CLASS.willSave;
	}
	
}
