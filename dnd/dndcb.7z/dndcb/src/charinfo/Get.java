package charinfo;
import data.*;
import java.util.Scanner;

public class Get {
	public static void stuff(Player p){
		Scanner sc = new Scanner(System.in);
		System.out.println("You have "+p.CLASS.money+"gp.");
		
		boolean good=false;
		while (!good) {
			System.out.println("What kind armor do you want?");
			System.out.print("None, Light, Medium, or Heavy: ");
			switch (sc.nextLine().toUpperCase().charAt(0)) {
			case 'N' : good = true; break;
			case 'L' : good = armorLight(p); break;
			case 'M' : good = armorMed(p); break;
			case 'H' : good = armorHeavy(p); break;
			default : System.out.println("That's not correct!");
			}
		}
		good=false;

		System.out.println("\nYou have "+p.CLASS.money+"gp.");
		while (!good) {
			System.out.println("Which kind of weapon do you want?");
			System.out.println("Simple, Martial, or None?");
			switch (sc.nextLine().toUpperCase().charAt(0)) {
			case 'S' : good = wepsSimple(p);
			case 'M' : good = wepsMartial(p);
			case 'N' : good = true; p.weapon = WeaponList.none; break;
			default : System.out.println("That's not correct!");
			}
		}
	}
	
	 static boolean armorLight(Player p) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Padded armor (5gp, 'P'),\n" +
				"Leather armor (10gp, 'L'),\n" +
				"Studded leather armor (25gp, 'S'),\n" +
				"Chain shirt (100gp, 'C')");
		boolean k;
		switch (sc.nextLine().toUpperCase().charAt(0)) {
		case 'P' : k = tryBuy(p,ArmorList.padded); break;
		case 'L' : k = tryBuy(p,ArmorList.leather); break;
		case 'S' : k = tryBuy(p,ArmorList.leatherStud); break;
		case 'C' : k = tryBuy(p,ArmorList.chainShirt); break;
		default : System.out.println("That's not correct!"); k=false;
		}
		return k;
	}
	 static boolean armorMed(Player p) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Hide armor (15gp, 'H'),\n" +
				"Scale mail (50gp, 'S'),\n" +
				"Chainmail (150gp, 'C'),\n" +
				"Breastplate (200gp, 'B')");
		boolean k = true;
		switch (sc.nextLine().toUpperCase().charAt(0)) {
		case 'H' :  k = tryBuy(p,ArmorList.hide); break;
		case 'S' :  k = tryBuy(p,ArmorList.scalemail); break;
		case 'C' :  k = tryBuy(p,ArmorList.chainmail); break;
		case 'B' :  k = tryBuy(p,ArmorList.breastplate); break;
		default : System.out.println("That's not correct!"); k=false;
		}
		return k;
	}
	 static boolean armorHeavy(Player p) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Splint mail (200gp, 'S'),\n" +
				"Banded mail (250gp, 'B'),\n" +
				"Half-plate (600gp, 'H'),\n" +
				"Full-plate (1500gp, 'F')");
		boolean k = true;
		switch (sc.nextLine().toUpperCase().charAt(0)) {
		case 'S' : k = tryBuy(p,ArmorList.splintmail); break;
		case 'B' : k = tryBuy(p,ArmorList.bandedmail); break;
		case 'H' : k = tryBuy(p,ArmorList.halfplate); break;
		case 'F' : k = tryBuy(p,ArmorList.fullplate); break;
		default : System.out.println("That's not correct!"); k=false;
		}
		return k;
	}
	
	 static boolean wepsSimple(Player p) {
		Scanner sc = new Scanner(System.in);
		WeaponList.showList(WeaponList.dagger); //
		WeaponList.showList(WeaponList.mace_light); //
		WeaponList.showList(WeaponList.sickle); //
		WeaponList.showList(WeaponList.club); //
		WeaponList.showList(WeaponList.mace_heavy); //
		WeaponList.showList(WeaponList.morningstar); //
		WeaponList.showList(WeaponList.spear); //
		WeaponList.showList(WeaponList.quarterstaff); //
		WeaponList.showList(WeaponList.crossbow_heavy); //
		WeaponList.showList(WeaponList.crossbow_light); //
		WeaponList.showList(WeaponList.javelin); //
		WeaponList.showList(WeaponList.sling); //
		boolean k = true;
		String line = sc.nextLine().trim().toUpperCase();
		switch (line.charAt(0)) {
		case 'D' : k = tryBuy(p,WeaponList.dagger); break;
		case 'L' : if (line.equals("LIGHT CROSSBOW")) {
						tryBuy(p,WeaponList.crossbow_light); k=true;
					} else if (line.equals("LIGHT MACE")) {
						tryBuy(p,WeaponList.mace_light); k=true;
					} else k=false;
					break;
		case 'S' : if (line.equals("SICKLE")) {
						tryBuy(p,WeaponList.sickle); k=true; 
					} else if (line.equals("SPEAR")) {
						tryBuy(p,WeaponList.spear); k=true;
					} else if (line.equals("SLING")){
						k = true;
					} else k=false;
					break;
		case 'C' : k = tryBuy(p,WeaponList.club); break;
		case 'H' :  if (line.equals("HEAVY CROSSBOW")) {
						tryBuy(p,WeaponList.crossbow_heavy); k=true;
					} else if (line.equals("HEAVY MACE")) {
						tryBuy(p,WeaponList.mace_heavy); k=true;
					} else k=false;
					break;
		case 'M' : tryBuy(p,WeaponList.morningstar); k=true;
		case 'Q' : tryBuy(p,WeaponList.quarterstaff); k=true;
		case 'J' : tryBuy(p,WeaponList.javelin); k=true;
		default : System.out.println("That's not correct!"); k=false;
		}
		return k;
	}
	 static boolean wepsMartial(Player p) {
		Scanner sc = new Scanner(System.in);
		for (int i=0;i<WeaponList.martial.length;i++) {
			System.out.println(WeaponList.martial[i].name+" ("+WeaponList.martial[i].cost+")");
		}
		String line = sc.nextLine().trim().toUpperCase();
		sc.close();
		if (WeaponList.checkList(line) == WeaponList.none)
			return true;
		else
			return false;
	}
	
	 static boolean tryBuy(Player p, Armor a) {
		if (p.gold>=a.cost) {
			p.CLASS.money-=a.cost;
			p.armor = a;
			return true;
		} else {
			System.out.println("You cannot afford that!");
			return false;
		}
	}
	 static boolean tryBuy(Player p, Weapon w) {
		if (p.gold>=w.cost){
			p.CLASS.money-=w.cost;
			p.weapon=w;
			return true;
		} else {
			System.out.println("You cannot afford that!");
			return false;
		}
	}
}
