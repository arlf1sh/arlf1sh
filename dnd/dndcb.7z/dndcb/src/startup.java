import java.util.Random;
import java.util.Scanner;

import charinfo.*;

public class startup {
	public static void main(String[] args) {
		System.out.println("Hello, and welcome to Zach & James's D&D 3.5e character builder!");
		System.out.println("Follow the prompts to get started right away.\n");
		Player player = new Player();
		
		CharacterCreator.raceSelect(player);
		System.out.println();
		CharacterCreator.classSelect(player);
		System.out.println();
		getAbilityScores(player);
		System.out.println();
		//get race and class
		Get.stuff(player);
		System.out.println();
		
		//now time to print errythin'
		System.out.println("Character creation complete!"
				+"============================"+"\n");
		System.out.println("Race: "+player.RACE.name);
		System.out.println("Class and level: "+player.CLASS.name+" 1");
		System.out.println("Hit points: "+player.HP());
		System.out.println("Armor Class (Touch AC) (Flat-footed AC): "+player.AC()+" ("+player.AC_Touch()+") ("+player.AC_Flat()+")");
		System.out.println("Speed: "+player.SPEED());
		System.out.println("Initiative Bonus: "+player.INITIATIVE());
		System.out.println("6 Base stats: "+player.strStat()+", "+player.dexStat()+", "+player.conStat()+", "+player.intStat()+", "+player.wisStat()+", "+player.chaStat());
		System.out.println("Saving throw rolls: "+player.fortitude()+", "+player.reflex()+", "+player.will());
		
		
	}
	static void getAbilityScores(Player p) {
		Random r = new Random();
		Scanner sc = new Scanner(System.in);
			int a1, a2, a3, a4, a5, a6;
			p.strBase = a1 = r.nextInt(6) + r.nextInt(6) + 8;
			p.dexBase = a2 = r.nextInt(6) + r.nextInt(6) + 8;
			p.conBase = a3 = r.nextInt(6) + r.nextInt(6) + 8;
			p.intBase = a4 = r.nextInt(6) + r.nextInt(6) + 8;
			p.wisBase = a5 = r.nextInt(6) + r.nextInt(6) + 8;
			p.chaBase = a6 = r.nextInt(6) + r.nextInt(6) + 8;
		System.out.println("These are your ability scores:");
		System.out.println(a1+", "+a2+", "+a3+", "+a4+", "+a5+", "+a6);
		System.out.println("In order: Strength, Dexterity, Constitution,\nIntelligence, Wisdom, Charisma");
	}
}
